import sys
from PyQt5.QtWidgets import QApplication, QDialog, QMessageBox
from RegisPersonaDialog import RegisPersonaDialog
from ConexionBD import *


class RegisPersonaApplication(QDialog):
    def __init__(self):
        super().__init__()

        self.datosTotal = Registro_datos()
        self.ui = RegisPersonaDialog()
        self.ui.setupUi(self)

        self.ui.btnGuardar.clicked.connect(self.registrar)

        self.show()

    def registrar(self):

        ident = self.ui.txtIdentidad.text()
        nom_comp = self.ui.txtNombres.text()
        ape_comp = self.ui.txtApellidos.text()
        fec_nac = self.ui.dtFechaNac.text()
        carrera = self.ui.cmbCarrera.currentText()

        self.datosTotal.inserta_producto(ident, nom_comp, ape_comp, fec_nac, carrera)
        self.ui.txtIdentidad.clear()
        self.ui.txtNombres.clear()
        self.ui.txtApellidos.clear()

        mensa = QMessageBox()
        mensa.setText('muy bien')
        mensa.exec_()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ventana = RegisPersonaApplication()
    ventana.show()
    sys.exit(app.exec_())
