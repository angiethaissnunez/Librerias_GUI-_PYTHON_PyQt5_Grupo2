import mysql.connector

class Registro_datos():

  def __init__(self):
      self.conn = mysql.connector.connect(host = "localhost",
                                        user = "root",
                                        password = "tupassword",
                                        database = "Pyqt5TareaDatos")

  def inserta_producto(self, identidad, nombre_completo, apellido_completo, fecha_nac, carrera):
      cur = self.conn.cursor()
      sql='''INSERT INTO datospersona (iddatospersona, nombres, apellidos, fechanacimiento, carrera)
      VALUES({},'{}','{}','{}','{}')'''.format(identidad, nombre_completo, apellido_completo, fecha_nac, carrera)
      cur.execute(sql)
      self.conn.commit()
      cur.close()